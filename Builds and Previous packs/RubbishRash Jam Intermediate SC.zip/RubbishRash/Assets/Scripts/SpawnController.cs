﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnController : MonoBehaviour
{

    public GameObject[] spawnPoints;
    public GameObject[] objectsToSpawn;
    public float spawnRate;
    private float nextTimeToSpawn;


    // Use this for initialization
    void Start()
    {
        spawnPoints = GameObject.FindGameObjectsWithTag("SpawnPoint");
        foreach (GameObject obj in spawnPoints)
        {
            obj.transform.parent = transform;
        }
        nextTimeToSpawn = 0;
    }

    // Update is called once per frame
    void Update()
    {

        if (Time.time >= nextTimeToSpawn && !GameController.instance.IsGameOver)
        {
            SpawnAtRandomPoint(objectsToSpawn[Random.Range(0, objectsToSpawn.Length)]);
            nextTimeToSpawn = Time.time + spawnRate;
            spawnRate *= 0.96f;
            spawnRate = Mathf.Clamp(spawnRate, 1f, 5);
        }

    }

    private void SpawnWave()
    {
        if (spawnPoints.Length == 0)
            return;
        foreach (GameObject obj in spawnPoints)
        {
            Instantiate(objectsToSpawn[Random.Range(0, objectsToSpawn.Length)], obj.transform.position, Quaternion.identity);
        }
    }

    private void SpawnAtRandomPoint(GameObject objToSpawn)
    {
        Instantiate(objToSpawn, spawnPoints[Random.Range(0, spawnPoints.Length)].transform.position, Quaternion.identity);
    }

}
