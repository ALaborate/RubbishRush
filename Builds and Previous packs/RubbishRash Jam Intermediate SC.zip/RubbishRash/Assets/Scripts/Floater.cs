﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Floater : MonoBehaviour
{
    public float degreesPerSecond = 15.0f;
    
 

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(new Vector3(0f, 0, Time.deltaTime * degreesPerSecond), Space.World);
        
    }
}
