﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class GameController : MonoBehaviour
{
    public  static GameController instance;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else Destroy(instance);
    }

    public bool IsGameOver;
    public Image gameOverPanel;
    public Text scoretxt;
    public int score;

    private void Update()
    {
        scoretxt.text = score.ToString();
        if (IsGameOver)
        {
            gameOverPanel.gameObject.SetActive(true);
        }

    }

}
