﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GarbageCollector : MonoBehaviour
{

    public int thresholdNumber;
    
    public static int counter;

    public static List<GameObject> firstThresholdPass;
    public static List<GameObject> secondThresholdPass;

    private void Start()
    {
        firstThresholdPass = new List<GameObject>();
        secondThresholdPass = new List<GameObject>();
        counter = 0;
    }
    void OnTriggerEnter2D(Collider2D col)
    {
        if(thresholdNumber == 1)
        {
            if(col.gameObject.tag == "Garbage")
            {
                if(secondThresholdPass.Contains(col.gameObject))
                {
                    secondThresholdPass.Remove(col.gameObject);
                }
                else
                {
                    firstThresholdPass.Add(col.gameObject);
                }
                
            }
        }

        if(thresholdNumber == 2)
        {
            if (col.gameObject.tag == "Garbage")
            {
                if (firstThresholdPass.Contains(col.gameObject))
                {
                    firstThresholdPass.Remove(col.gameObject);
                    Destroy(col.gameObject);
                    counter++;
                }
                else
                {
                    secondThresholdPass.Add(col.gameObject);
                }
            }

        }
    }

    private void Update()
    {
        
    }
}
