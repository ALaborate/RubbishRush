﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Garbage : MonoBehaviour
{
    public float minPoisonRadius = 0.2f;
    public float maxPoisonRadius = 6f;
    public float poisonExtentionPerSecond = 0.1f;
    public float poisonDamagePerSecond = 10f;

    private CircleCollider2D poisonTrigger;
    private float awakeTime;

    private void Awake()
    {
        awakeTime = Time.time;
    }

    // Start is called before the first frame update
    void Start()
    {
        poisonTrigger = gameObject.AddComponent<CircleCollider2D>();
        poisonTrigger.radius = minPoisonRadius;
        poisonTrigger.isTrigger = true;
    }

    // Update is called once per frame
    void Update()
    {
        poisonTrigger.radius = Mathf.Min(minPoisonRadius + (poisonExtentionPerSecond) * (Time.time - awakeTime), maxPoisonRadius);
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        var hc = collision.gameObject.GetComponent<HealthCare>();
        if(hc!=null)
        {
            hc.ReceiveDamage(new Damage() { ammount = poisonDamagePerSecond * Time.deltaTime });
        }
    }
}
