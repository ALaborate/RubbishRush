﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hook : MonoBehaviour
{
    public int minPosition;
    public int maxPosition;
    private void Start()
    {
        transform.localPosition -= new Vector3(0, Random.Range(minPosition, maxPosition + 1), 0);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Fish"))
        {
            //Kill fish
        }
        else if (collision.CompareTag("Net"))
        {
            // Add score GameController.instance.score+=n;
        }
    }
}
